


@if(Session::get('user_id')==''))
@php
 header("Location: " . URL::to('/'), true, 302);
        exit(); @endphp

@else

@endif

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>WAD- Group D | Admin</title>
  <meta name="description" content="Demo | Demo Admin">
  <meta name="author" content="Demo Web Development - https://domain">

  @include('layouts.partials.styles')

  @yield('styles')

</head>

<body class="adminbody">

  <div id="main">

    <!-- top bar navigation -->
    @include('layouts.partials.nav')
    <!-- End Navigation -->


    <!-- Left Sidebar -->
      @include('layouts.partials.sidebar')
    <!-- End Sidebar -->


    <div class="content-page">

      <!-- Start content -->
      <div class="content">

        <div class="container-fluid">

          @section('content')
          @show


        </div>
        <!-- END container-fluid -->

      </div>
      <!-- END content -->

    </div>
    <!-- END content-page -->

  @include('layouts.partials.footer')

  </div>
  <!-- END main -->

  @include('layouts.partials.scripts')

  @yield('scripts')

</body>
</html>
