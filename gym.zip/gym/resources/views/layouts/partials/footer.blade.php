<footer class="footer">
  <span class="text-right">
    {{ __('admin.copyright') }} <a target="_blank" href="http://agramonia.com">Agramonia</a>
  </span>
  <span class="float-right">
    {{ __('admin.powered_by') }} <a target="_blank" href="http://work-fort.net"><b>WorkFort</b></a>
  </span>
</footer>
