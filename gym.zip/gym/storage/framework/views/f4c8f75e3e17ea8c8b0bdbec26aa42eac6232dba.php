<?php $__env->startSection('content'); ?>
use DB;

<div class="container-fluid">
<style>
  input[type=checkbox]
{
  /* Double-sized Checkboxes */
  -ms-transform: scale(1.5); /* IE */
  -moz-transform: scale(1.5); /* FF */
  -webkit-transform: scale(1.5); /* Safari and Chrome */
  -o-transform: scale(1.5); /* Opera */
  transform: scale(1.5);
  padding: 10px;
}
</style>
  <div class="col-lg-12">
    <div class="row mb-4 mt-4">
      <div class="col-md-12">
        
      </div>
    </div>






    <div class="row">
      <!-- FORM Panel -->

      <!-- Table Panel -->
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <b>Active Member List</b>
            <span class="">

              <button class="btn btn-success btn-block btn-sm col-sm-2 float-right" type="button" id="new_member">
          </button>
        </span>
          </div>
          <div class="card-body">
            
            <table class="table table-bordered table-condensed table-hover">
              <colgroup>
                <col width="5%">
                <col width="15%">
                <col width="20%">
                <col width="20%">
                <col width="20%">
                <col width="10%">
              </colgroup>
              <thead>
                <tr>
                
                  <th class="">Member ID</th>
                  <th class="">Name</th>
                  <th class="">Plan</th>
                  <th class="">Contact</th>
                   <th class="">Address</th>
                  
                 
                  <th class="text-center">Action</th>
                </tr>
              </thead>

                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tbody>
                
                <tr>
                  
                  <td class="text-center"><?php echo e($m->member_id); ?></td>
                  <td class="">
                     <p><b><?php echo e($m->firstname); ?></b></p>
                     
                  </td>

                  <?php $plan = DB::table('plans')->where('id',$m->plan_id)->get();  ?>

                  <td class=""> 
                     <p><b><?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($p->package); ?> ( <?php echo e($p->months); ?> month/s) <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></b></p>
                     
                  </td>
                  <td class="">
                     <p><b><?php echo e($m->contact); ?></b></p>
                  </td>
                  <td class="">
                     <p><b><?php echo e($m->address); ?></b></p>
                     
                  </td>
                 
                  <td class="text-center">
                    <a  data-toggle="modal" data-target="#currency<?php echo e($m->id); ?>" class="currency_link d-inline dropdown mb-2 text-mute btn btn-info">Edit</a>
                    <a href="<?php echo e(route('delmem',$m->id)); ?> " class="btn btn-sm btn-outline-danger delete_member" type="button" data-id="">Delete</a>
                  </td>
                </tr>
                
              </tbody>



 <?php $row=DB::table('members')->where('id',$m->id)->get(); ?> 
  
  <div  class="modal fade" id="currency<?php echo e($m->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    
    
      <div class="modal-body">
     <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
  <form method="POST" action="<?php echo e(route('edit_members')); ?>">
                        <?php echo csrf_field(); ?>

<div class="form-group ">

  <label class="d-inline small text-dark mb-1 ml-1" for="inputEmailAddress">Name</label>
                                            
                                            <input type="number" hidden name="id" value="<?php echo e($m->id); ?>">
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="name" name="name" id="inputEmailAddress" 
                                           autocomplete="email" autofocus value="<?php echo e($r->firstname); ?>"  /></div>   

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">member_id</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-4 px-2 my-2" type="number" name="member_id" id="inputEmailAddress" 
                                             autocomplete="email" autofocus value="<?php echo e($r->member_id); ?>" /></div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">plan_id</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="number" name="plan_id"  id="inputEmailAddress" 
                                           autocomplete="email" autofocus value="<?php echo e($r->plan_id); ?>"  /></div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">Address</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="text" name="address"  id="inputEmailAddress" 
                                            autocomplete="email" autofocus value="<?php echo e($r->address); ?>"  /></div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">Gender</label>
                                            
                                           <select class="ml-5" name="gender">
                                             <option value="male">Male</option>
                                             <option value="female">Female</option>

                                           </select>
                                           </div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">Contact</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="number" name="contact"  id="inputEmailAddress" 
                                            autocomplete="email" autofocus  value="<?php echo e($r->contact); ?>"  /></div>                                                                                                  


                                           

                                          

                                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                  
                                            <div class="form-group d-flex align-items-center justify-content-between mt-5 mb-0">
                                            <?php if(Route::has('forgetPass')): ?> 
                                            <a href="<?php echo e(route('password.request')); ?>" class="text">Forgot password ?</a> <?php endif; ?>
                                            
                                            <input style="margin-left: 100px;background: aliceblue;border-radius: 20px; " type="submit"class=" w-25 btn btn-info text-dark d-block font-weight-bold " href="" name="add" value="Update" /></div>
                    </form> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
      </div>
    
    
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>
  




              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
      </div>
      <!-- Table Panel -->
    </div>
  </div>  

</div>



<style>
  
  td{
    vertical-align: middle !important;
  }
  td p{
    margin: unset
  }
  img{
    max-width:100px;
    max-height: :150px;
  }
</style>
<script>
  $(document).ready(function(){
    $('table').dataTable()
  })
  $('#new_member').click(function(){
    uni_modal("<i class='fa fa-plus'></i> New Membership Plan","manage_membership.php",'')
  })
  $('.view_member').click(function(){
    uni_modal("<i class='fa fa-address-card'></i> Member Plan Details","view_pdetails.php?id="+$(this).attr('data-id'),'')
    
  })
  $('.edit_member').click(function(){
    uni_modal("<i class='fa fa-edit'></i> Manage Member Details","manage_member.php?id="+$(this).attr('data-id'),'mid-large')
    
  })
  $('.delete_member').click(function(){
    _conf("Are you sure to delete this topic?","delete_member",[$(this).attr('data-id')],'mid-large')
  })

  function delete_member($id){
    start_load()
    $.ajax({
      url:'ajax.php?action=delete_member',
      method:'POST',
      data:{id:$id},
      success:function(resp){
        if(resp==1){
          alert_toast("Data successfully deleted",'success')
          setTimeout(function(){
            location.reload()
          },1500)

        }
      }
    })
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gym\resources\views/pages/see_members.blade.php ENDPATH**/ ?>