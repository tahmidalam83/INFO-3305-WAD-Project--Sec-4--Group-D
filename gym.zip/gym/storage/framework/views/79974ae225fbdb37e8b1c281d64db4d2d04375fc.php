


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Log In - GYM</title>

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <link href="admin.css" rel="stylesheet" type="text/css" media="all"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    
    

    
    
    
    
    
        <body class=""> <h4 class="text-center m-auto" >
                                                    <?php if(session()->has('reset')): ?>
                                                   <?php echo e(Session::get('reset')); ?>

                                                    <?php endif; ?> </h4>
    
    
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Login')); ?> - GYM Management System</div>

                <div class="card-body text-center ">
                    <form method="POST" action="<?php echo e(route('adminLogin')); ?>">
                        <?php echo csrf_field(); ?>

<div class="form-group "><label class="d-inline small text-dark mb-1" for="inputEmailAddress">Email</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="email" name="email" placeholder="Enter your email" id="inputEmailAddress" 
                                            value="<?php echo e(old('email')); ?>" autocomplete="email" autofocus  /></div>
                                            
                                       

                                                                                        
                                                                                        
                                            <div class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-group"><label class=" d-inline text-dark small mb-1" for="inputPassword">Password</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-4 my-2 px-2" name="password" id="inputPassword" type="password" placeholder="Enter password"
                                            value=""            /></div>
                                            

                                          

                                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                       
                                            <div class="form-group d-flex align-items-center justify-content-between mt-5 mb-0">
                                            <?php if(Route::has('forgetPass')): ?> 
                                            <a href="<?php echo e(route('password.request')); ?>" class="text">Forgot password ?</a> <?php endif; ?>
                                            
                                            <input style="margin-left: 210px; background: aliceblue;border-radius: 20px; " type="submit"class=" -4 w-50 btn btn-info text-dark d-block font-weight-bold " href="" name="Login" value="Login" /></div>
                    </form>




  


                </div>
            </div>
        </div>
    </div>
</div>


       <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
    </body>
</html><?php /**PATH C:\xampp\htdocs\gym\resources\views/login.blade.php ENDPATH**/ ?>