<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-xl-12">
      <div class="breadcrumb-holder">
        <h1 class="main-title float-left"><?php echo e(__('admin.admin')); ?></h1>
        <ol class="breadcrumb float-right">
            <li class="breadcrumb-item"><a href=""><?php echo e(__('admin.dashboard')); ?></a></li>
            <li class="breadcrumb-item active"><?php echo e(__('admin.admin')); ?></li>
        </ol>
        <div class="clearfix"></div>
      </div>
    </div>
  </div>

  <div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <div class="card mb-3">
        <div class="card-header">
          <h3><i class="fa fa-table"></i> <?php echo e(__('admin.admin')); ?> <?php echo e(__('admin.list')); ?></h3>
          <a href="" class="btn btn-success btn-sm float-right"><?php echo e(__('admin.add')); ?> <?php echo e(__('admin.admin')); ?></a>
        </div>

        <div class="card-body">
         
          <div class="table-responsive">
            <table id="table" class="table table-bordered table-hover display">
              <thead>
                <tr>
                  <th><?php echo e(__('admin.name')); ?></th>
                  <th><?php echo e(__('admin.email')); ?></th>
                  <th><?php echo e(__('admin.username')); ?></th>
                  <th><?php echo e(__('admin.phone')); ?></th>
                  <th><?php echo e(__('admin.type')); ?></th>
                  <th><?php echo e(__('admin.action')); ?></th>
                </tr>
              </thead>
              <tbody>
               
              </tbody>
            </table>
          </div>

        </div>
      </div><!-- end card-->
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
  $(document).ready(function() {
    $('#table').DataTable();
  } );
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\agramonia\resources\views/admin/index.blade.php ENDPATH**/ ?>