<div class="left main-sidebar">

  <div class="sidebar-inner leftscroll">

    <div id="sidebar-menu" class=" show">

      <ul class=" show">

        

						
				
        <li class="submenu open">
          <a href="#" class=""><i class="fa fa-fw fa-bars"></i> <span> <?php echo e("Menu"); ?> </span> <span class="menu-arrow"></span></a>
          <ul class="list-unstyled">
          	<li><a href="<?php echo e(route('home')); ?>" class=""><?php echo e('Home'); ?></a></li>
            <li><a href="<?php echo e(route('add_members')); ?>" class=""><?php echo e('Add Member'); ?> </a></li>
            <li><a href="<?php echo e(route('see_members')); ?>" class=""><?php echo e('Members'); ?></a></li>
            <li><a href="<?php echo e(route('plans')); ?>" class=""><?php echo e('Plans/Packages'); ?></a></li>
            <li><a href="<?php echo e(route('trainers')); ?>" class=""><?php echo e('Trainers'); ?></a></li>
            <li><a href="<?php echo e(route('users')); ?>" class=""><?php echo e('Users'); ?></a></li>
          </ul>
        </li>
       

      </ul>

      <div class="clearfix"></div>

    </div>

    <div class="clearfix"></div>

  </div>

</div>
<?php /**PATH C:\xampp\htdocs\laravel_projects\gym\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>