

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row">
			<!-- FORM Panel -->
			<div class="col-md-4">
			<form action="<?php echo e(route('addtrain')); ?>" method="post" > <?php echo csrf_field(); ?>
				<div class="card">
					<div class="card-header">
						    Trainer Form
				  	</div>
					<div class="card-body">
							<input type="hidden" name="id">
							<div class="form-group">
								<label class="control-label">Name</label>
								<input type="text" class="form-control" name="name">
							</div>
							<div class="form-group">
								<label class="control-label">Email</label>
								<input type="email" class="form-control" name="email">
							</div>
							<div class="form-group">
								<label class="control-label">Contact</label>
								<input type="text" class="form-control" name="contact">
							</div>
							<div class="form-group">
								<label class="control-label">Rate</label>
								<input type="number" class="form-control" name="rate">
							</div>
					</div>
							
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button type="submit" class="btn btn-md btn-success col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-md btn-secondary col-sm-3" type="button" onclick="_reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
			<!-- FORM Panel -->

			<!-- Table Panel -->
			<div class="col-md-8">
				<div class="card">
					<div class="card-header">
						<b>List of Trainers</b>
					</div>
					<div class="card-body">
						

						 
						  <table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th class="text-center">Name</th>
									<th class="text-center">Information</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							
							 <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <tbody>
								
								<tr>
									<td class="text-center"><?php echo e($t->name); ?></td>
									<td class="">
										<p><i class="fa fa-user"></i> <b>Contact: <?php echo e($t->contact); ?></b></p>
										<p><small><i class="fa fa-at"></i> <b>Email: <?php echo e($t->email); ?></b></small></p>
										<p><small><i class="fa fa-phone-square-alt"></i> <b>Rate:<?php echo e($t->rate); ?></b></small></p>
										
										
									</td>
									<td class="text-center">
										<a  data-toggle="modal" data-target="#currency<?php echo e($t->id); ?>" class="currency_link d-inline dropdown mb-2 text-mute btn btn-info">Edit</a>
										<a href="<?php echo e(route('deltrain',$t->id)); ?>" class="btn btn-md btn-outline-danger delete_plan" type="button" data-id="">Delete</a>
									</td>
								</tr>
								
							</tbody>



 <?php $row=DB::table('trainers')->where('id',$t->id)->get(); ?> 
  
  <div  class="modal fade" id="currency<?php echo e($t->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    
    
      <div class="modal-body">
     <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    	<form action="<?php echo e(route('edittrain')); ?>" method="post" > <?php echo csrf_field(); ?>
				<div class="card">
					<div class="card-header">
						    Trainer Form
				  	</div>
					<div class="card-body">
							<input type="hidden" name="id" name="id" value="<?php echo e($t->id); ?>">
							<div class="form-group">
								<label class="control-label">Name</label>
								<input type="text" class="form-control"  value="<?php echo e($t->name); ?>" name="name">
							</div>
							<div class="form-group">
								<label class="control-label">Email</label>
								<input type="email" class="form-control" value="<?php echo e($t->email); ?>" name="email">
							</div>
							<div class="form-group">
								<label class="control-label">Contact</label>
								<input type="text" class="form-control" value="<?php echo e($t->contact); ?>" name="contact">
							</div>
							<div class="form-group">
								<label class="control-label">Rate</label>
								<input type="number" class="form-control" value="<?php echo e($t->rate); ?>" name="rate">
							</div>
					</div>
							
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<button type="submit" class="btn btn-md btn-success col-sm-3 offset-md-3"> Save</button>
								<button class="btn btn-md btn-secondary col-sm-3" type="button" onclick="_reset()"> Cancel</button>
							</div>
						</div>
					</div>
				</div>
			</form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
      </div>
    
    
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>
  



							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<style>
	
	td{
		vertical-align: middle !important;
	}
	td p{
		margin:unset;
	}
</style>
<script>
	function _reset(){
		$('#manage-trainer').get(0).reset()
		$('#manage-trainer input,#manage-trainer textarea').val('')
	}
	$('#manage-trainer').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_trainer',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})
	$('.edit_trainer').click(function(){
		start_load()
		var cat = $('#manage-trainer')
		cat.get(0).reset()
		cat.find("[name='id']").val($(this).attr('data-id'))
		cat.find("[name='name']").val($(this).attr('data-name'))
		cat.find("[name='email']").val($(this).attr('data-email'))
		cat.find("[name='contact']").val($(this).attr('data-contact'))
		cat.find("[name='rate']").val($(this).attr('data-rate'))
		end_load()
	})
	$('.delete_trainer').click(function(){
		_conf("Are you sure to delete this trainer?","delete_trainer",[$(this).attr('data-id')])
	})
	function delete_trainer($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_trainer',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
	$('table').dataTable()
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gym\resources\views/pages/trainer.blade.php ENDPATH**/ ?>