<style>
    @import  url(https://fonts.googleapis.com/css?family=PT+Sans:400,400italic,700,700italic);
    * {
        font-family: 'PT Sans', sans-serif;
        font-weight: lighter;
    }

    .header { grid-area: header; }
    .left { grid-area: left; width: 5em;}
    .main { grid-area: main; }
    .right { grid-area: right; width: 5em;}
    .footer { grid-area: footer; }

    .grid-container {
        display: grid;
        grid-template-areas:
            'left header header header right'
            'left main main main right'
            'left footer footer footer right';
        grid-gap: 10px;
        padding: 10px;
    }

    .header-logo{
        grid-column-start: 2;
        grid-column-end: 3;
    }

    .header-nav{
        grid-column-start: 3;
        grid-column-end: 5;
    }

    .header-lang{
        grid-column-start: 4;
        grid-column-end: 5;
    }

    .lang, .nav, .langnav{
        display: inline-block;
    }

    .topnav { grid-area: top; }
    .title { grid-area: bottom; }
    .header-nav{
        display: grid;
        grid-template-areas:
            'top'
            'bottom';
        grid-gap: 10px;
        padding: 10px;
    }

    .nav { grid-area: leftnav; }
    .langnav { grid-area: rightnav; }
    .topnav{
        display: grid;
        grid-template-areas:
            'leftnav rightnav';
        grid-gap: 10px;
        padding: 10px;
    }

    .main-left, .main-right{
        width: 5em;
    }

    .main-left{
        grid-column-start: 2;
        grid-column-end: 3;
    }

    .main-content{
        margin-top: 3em;
        margin-bottom: 3em;
        margin-left: -12em;
        grid-column-start: 3;
        grid-column-end: 4;
    }

    .main-right{
        grid-column-start: 4;
        grid-column-end: 5;
    }

    .image{
        display: inline-block;
        width: 32%;
        height: 100%:
    }

    .image img{
        max-width: 100%;
    }

    .footer-image{
        width: 100%;
        height: 500px;
        background-image: url('/images/footer.png');
        background-size: 100% 100%;
        background-repeat: no-repeat;
        grid-column-start: 1;
        grid-column-end: 6;
    }

    .bank-info{
        margin-left: 2em;
        width: 18rem;
        margin-top: 30vh;
        grid-column-start: 2;
        grid-column-end: 3;
    }

    .bottom-footer{
        display: flex;
        justify-content: flex-end;
        align-items: flex-end;
        grid-column-start: 2;
        grid-column-end: 5;
    }

    .bottom-footer span{
        width: 100%;
    }

    .nav a{
        font-size: 1.25em;
        margin: 0 0.3em;
        color: black;
        text-decoration: none;
    }

    .title h1{
        color: #b3b3b3;
        letter-spacing: 0.2em;
        font-size: 24px;
    }

    .main-text h2{
        font-size: 1.2em;
        font-weight: bold;
        margin-top: 2em;
    }

    .main-text p{
        font-size: 1.2em;
    }

    .topnav{
        padding: 0;
    }
</style>

<div class="grid-container">
    <div class="left"></div>
    <div class="header header-logo">
        <div class="logo">
            <img src="<?php echo e(URL('/images/PatriSaxo_web.png')); ?>">
        </div>
        
    </div>
    <div class="header header-nav">
        <div class="topnav">
            <div class="nav">
                <a class="active" href="#about">Association</a>
                <a href="#blog">Blog</a>
                <a href="#monuments">Monuments</a>
                <a href="#publications">Publications</a>
                <a href="#donations">Donations</a>
                <a href="#contact">Contact</a>
            </div>
            <div class="langnav">
                <div class="lang de">
                    <img src="<?php echo e(URL('/images/deutsch.png')); ?>">
                </div>
                <div class="lang ro">
                    <img src="<?php echo e(URL('/images/rumanisch.png')); ?>">
                </div>
            </div>
        </div>
        <div class="title">
            <h1>Stiftung zur Erhaltung des sächsischen Kulturerbes in Siebenbürgen</h1>
        </div>
    </div>
    <div class="main main-left"></div>
    <div class="main main-content">
        <div class="main-images">
            <div class="image image-1">
                <img src="<?php echo e(URL('/images/Home_1.jpg')); ?>">
            </div>
            <div class="image image-2">
                <img src="<?php echo e(URL('/images/home_2.jpg')); ?>">
            </div>
            <div class="image image-3">
                <img src="<?php echo e(URL('/images/home_3.jpg')); ?>">
            </div>
        </div>
        <div class="main-text">
            
            <h2>Engagement für den Erhalt des sächsischen Kulturerbes in Siebenbürgen</h2>

            <p>Die Stiftung “Patrimonium Saxonicum – Stiftung zur Erhaltung des sächsischen
            Kulturerbes in Siebenbürgen” möchte als Nachfolgerin des Architekturbüros Hermann
            Fabini einen Beitrag zur Erhaltung des siebenbürgisch-sächsischen Kulturerbes leisten.
            Darunter verstehen wir bewegliche und unbewegliche Güter, die als Zeugnis
            siebenbürgisch-sächsischen Lebens wichtig und erhaltenswert sind. Die Arbeit der
            Stiftung konzentriert sich auf den in Siebenbürgen befindlichen Teil des sächsischen
            Kulturerbes.</p>

            <h2>Erfahren Sie mehr über:</h2>

            <p>Die Stiftung, das siebenbürgisch-sächsische Kulturerbe, Veröffentlichungen und
            Unterstützungsmöglichkeiten.</p>
            
        </div>
    </div>
    <div class="main main-right"></div>

    <div class="footer footer-image">
       
  
    </div>

    <div class="footer bank-info">
        Bankverbindung<br>
        Banca Transilvania Swift: BTRLRO22<br>
        Euro: RO11 BTRL EURC RT0V 1394 3201<br>
        Lei: RO26 BTRL RONC RT0V 1394 3201<br>
    </div>

    <div class="footer bottom-footer">
        <span>© 2022 Patrimonium Saxonicum – Stiftung zur Erhaltung des sächsischen Kulturerbes in Siebenbürgen</span>
    </div>


    <div class="right"></div>
   
</div><?php /**PATH /opt/lampp/htdocs/laravel_tut/agramonia/resources/views/home.blade.php ENDPATH**/ ?>