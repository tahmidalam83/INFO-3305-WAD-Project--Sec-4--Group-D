<div class="left main-sidebar">

  <div class="sidebar-inner leftscroll">

    <div id="sidebar-menu">

      <ul>

        

							


								<a href="" class="">
									<i class=""></i> 
									<span>
										
											<i class="fa fa-info text-danger"></i>
									
									</span>
								</a>
							
								<a href="#" class="
									
								">
									<i class=""></i>
									<span>
										
											<i class="fa fa-info text-danger"></i>
								
									</span>
									<span class="menu-arrow"></span>
								</a>
								<ul class="list-unstyled">
									
											<li>
												<a href="" class=" active-submenu"><i class=""></i>
													
												</a>
											</li>
										
								</ul>
							
						</li>
			
				<li class="submenu">
					
						<a href="" class="">
							<i class=""></i> 
							<span>
							
							</span>
						</a>
					
						<a href="#" class="
							
                        ">
							<i class=""></i>
							<span>
							
							</span>
							<span class="menu-arrow"></span>
						</a>
				
					<ul class="list-unstyled">
						
								<li>
									<a href="" class=""><i class=""></i>
										
									</a>
								</li>
						
					</ul>
				</li>
		
        <li class="submenu">
          <a href="#" class=""><i class="fa fa-fw fa-bars"></i> <span> <?php echo e("Menu"); ?> </span> <span class="menu-arrow"></span></a>
          <ul class="list-unstyled">
            <li><a href="<?php echo e(route('add_product')); ?>" class=""><?php echo e('Add product'); ?> </a></li>
            <li><a href="<?php echo e(route('see_products')); ?>" class=""><?php echo e('See all products'); ?></a></li>
          </ul>
        </li>
        --}}

      </ul>

      <div class="clearfix"></div>

    </div>

    <div class="clearfix"></div>

  </div>

</div>
<?php /**PATH C:\xampp\htdocs\laravel_projects\agramonia\resources\views/admin/layouts/partials/sidebar.blade.php ENDPATH**/ ?>